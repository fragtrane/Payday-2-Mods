Don Pastrami Beak Suppressor Fix

Warning: This mod fixes the invisible suppressor model when equipping the Beak Suppressor with the Don Pastrami Barrel on the Platypus 70. However, the mod breaks if you use the default barrel with the Beak Suppressor and equip a sniper scope (Default Sniper Scope, Theia Magnified Scope, Box Buddy Sight). If you do this, you will see a floating silencer when you aim down sights.

A proper fix requires BeardLib and is part of the Add-On Legendary Attachments Mod available here:
- https://modworkshop.net/mod/27211

If you cannot use BeardLib for whatever reason, you could alternatively consider the Platypus Beak Suppressor Replacements mod which will let you choose a different suppressor model to use when you have the Don Pastrami Barrel equipped:
- https://modworkshop.net/mod/31852

----

v1.0 - 2021-04-15
